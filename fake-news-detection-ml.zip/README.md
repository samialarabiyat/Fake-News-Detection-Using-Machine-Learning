
# 📰 Fake News Detection using Machine Learning

This project applies machine learning to detect fake news articles using natural language processing techniques.  
We trained a **Passive Aggressive Classifier** on labeled news text data and achieved high accuracy.

---

## 🔍 Dataset

Used a small subset of the [Fake and Real News Dataset](https://www.kaggle.com/datasets/clmentbisaillon/fake-and-real-news-dataset) with two classes:
- **Fake News** (label = 0)
- **True News** (label = 1)

Features:
- Only the `text` column (cleaned and vectorized using TF-IDF)

---

## 🤖 Model

- **Model**: PassiveAggressiveClassifier (scikit-learn)
- **Vectorizer**: TfidfVectorizer
- **Accuracy**: ~94.5% on test set (with small sample)
- **Evaluation**: Precision, Recall, F1-score, Confusion Matrix

---

## 📂 Structure

```
fake-news-detection-ml/
│
├── data/
│   └── fake_news_sample.csv
│
├── notebook/
│   └── fake_news_training.py
│
├── requirements.txt
└── README.md
```

---

## 📦 Requirements

```bash
pip install pandas scikit-learn matplotlib seaborn
```
